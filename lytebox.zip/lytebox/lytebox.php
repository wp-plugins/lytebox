<?php
/*
Plugin Name: Lytebox	
Plugin URI: http://www.dolem.com/lytebox/
Version: 3.22
*/
?>

<script type="text/javascript" language="javascript" src="<?php bloginfo('url'); ?>/wp-content/plugins/lytebox/lytebox.js"></script>
<link rel="stylesheet" href="<?php bloginfo('url'); ?>/wp-content/plugins/lytebox/lytebox.css" type="text/css" media="screen" />

